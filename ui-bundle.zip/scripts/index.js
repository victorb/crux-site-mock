function onDomLoaded(...events) {
    window.addEventListener("DOMContentLoaded", function() {
        for(let i = 0; i < events.length; i++){
	    events[i]();
        }
    });
}

function tabsEvent(e, tabs, codes) {
    let nthCode;

    // to highlight the right tab on click and
    // toggle the right code
    for(let i = 0; i < tabs.length; i++){
	if(e.target == tabs[i]) {
            nthCode = i;
	}
	codes[i].classList.remove("editor__code--visited");
	codes[i].classList.add("editor__code--hidden");
        tabs[i].classList.remove("editor__tabs__tab--visited");
    }

    e.target.classList.add("editor__tabs__tab--visited");
    codes[nthCode].classList.replace("editor__code--hidden", "editor__code--visited");
}

function addTabsOnClick() {
    // to assign listener to the three api sections
    let sections = [["tab-first", "code-first"],
		    ["tab-second", "code-second"],
		    ["tab-third", "code-third"]];

    for(let i = 0; i < sections.length; i++) {
	let tabs = document.getElementsByClassName(sections[i][0]);
	let codes = document.getElementsByClassName(sections[i][1]);

	for(let a = 0; a < tabs.length; a++){
            tabs[a].addEventListener("click", function(e) {
                tabsEvent(e, tabs, codes);
	    });
	};
    }
}

function addSmoothScroll() {
    let links = document.getElementsByClassName("ots-learn-link");

    for(let i = 0; i < links.length; i++) {

	links[i].addEventListener("click", function (event) {

	    let targetId = links[i].getAttribute("data-ref");
	    let target = document.getElementById(targetId);

	    target.scrollIntoView({ behavior: "smooth", block: "start"});
            event.preventDefault();

	}, false)};
}

onDomLoaded(// addTabsOnClick,
            addSmoothScroll);

var scrollInterval = null;

function stopScroll() {
    clearInterval(scrollInterval)
}

function runAutoScroll(ss) {
    stopScroll();
    let s = ss || 0.2;
    function autoScroll () {
        if (window.scrollY > document.body.scrollHeight - window.innerHeight - 2)
            y = 0;
        window.scrollTo(0,(y=y+s,y));
    }
    let y = 0;
    scrollInterval = setInterval(autoScroll,1);
    return scrollInterval;
}
