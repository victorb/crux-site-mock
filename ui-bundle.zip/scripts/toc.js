/////////// UTILITIES ///////////
function expandArrow(node) {
    node.classList.replace("arrow-untoggle", "arrow-toggle");
}

function reduceArrow(node) {
    node.classList.replace("arrow-toggle", "arrow-untoggle");
}

function expandTocMenu(node) {
    node.classList.replace("toc-wrapper-untoggle", "toc-wrapper-toggle");
}

function reduceTocMenu(node) {
    node.classList.replace("toc-wrapper-toggle", "toc-wrapper-untoggle");
}

function expandTocGroup(node) {
    node.classList.replace("group-untoggle", "group-toggle");
}

function reduceTocGroup(node) {
    node.classList.replace("group-toggle", "group-untoggle")
}

/////////// ON-CLICK EVENTS ///////////

function toggleToc() {
    let toc = document.getElementById("toc-wrapper");
    let arrow =  document.getElementById("arrow");

    // to minimize the toc list when clicking on button
    if(arrow.classList.contains("arrow-toggle") === true) {
        reduceArrow(arrow);
        reduceTocMenu(toc);
    }
    // to expand the toc list
    else {
        expandArrow(arrow);
	expandTocMenu(toc);
    }
}
