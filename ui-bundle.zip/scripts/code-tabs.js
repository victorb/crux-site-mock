function addCodeTabs() {
    var hash = window.location.hash
    var tabsets = find('.tabset')
    tabsets.forEach(function (tabset) {
	var tabs = tabset.querySelector('.tabs')
	if (tabs) {
	    var first
	    var tabHeadings = getHeadings(tabs)
	    var firstHeading = find('p', tabs)[0].innerText
	    var selectedHeading = window.localStorage.getItem(tabHeadings) || firstHeading
	    find('li', tabs).forEach(function (tab, idx) {
		var id = (tab.querySelector('a[id]') || tab).id
		var pane = getPane(id, tabset)
		if (tab.innerText == selectedHeading) {
		    tab.classList.add('is-active')
		    if (pane) pane.classList.add('is-active')
		} else {
		    tab.classList.remove('is-active')
		    if (pane) pane.classList.remove('is-active')
		}
		tab.addEventListener('click', activateTab.bind({ tabsets: tabsets, tabHeadings: getHeadings(tabs), tab: tab}))
	    })
	}
	tabset.classList.remove('is-loading')
    })

    function activateTab (e) {
	var tab = this.tab
	var tabsets = this.tabsets
	var tabHeadings = this.tabHeadings
	var tabHeading = tab.innerText
	var tabHeightBefore = tab.offsetTop
	window.localStorage.setItem(tabHeadings,tabHeading)
	this.tabsets.forEach(function (tabset) {
	    if (getHeadings(tabset.querySelector('.tabs')) === tabHeadings) {
		find('.tabs li', tabset).forEach(function (tab) {
		    var id = (tab.querySelector('a[id]') || tab).id
		    var pane = getPane(id, tabset)
		    if (tab.innerText === tabHeading) {
			tab.classList.add('is-active')
			if (pane) pane.classList.add('is-active')
		    } else {
			tab.classList.remove('is-active')
			if (pane) pane.classList.remove('is-active')
		    }
		})

	    }
	})
	var tabHeightAfter = tab.offsetTop
	window.scrollBy(0, tabHeightAfter - tabHeightBefore)
    }

    function find (selector, from) {
	return Array.prototype.slice.call((from || document).querySelectorAll(selector))
    }

    function getHeadings (tabs) {
	return find('p', tabs).map(p => p.innerText).sort().toString()
    }

    function getPane (id, tabset) {
	return find('.tab-pane', tabset).find(function (it) {
	    return it.getAttribute('aria-labelledby') === id
	})
    }
}

window.addEventListener("DOMContentLoaded", function() {
    addCodeTabs();
});
